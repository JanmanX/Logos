from logos.__main__ import cli

cli()
