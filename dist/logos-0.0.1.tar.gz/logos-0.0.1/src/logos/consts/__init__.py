# Register size in bytes
REGISTER_SIZE = 8
